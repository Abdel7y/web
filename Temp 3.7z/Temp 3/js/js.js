//for option box color
$(".icon-option").click(function(){
    $(".color-option").show();
);
}