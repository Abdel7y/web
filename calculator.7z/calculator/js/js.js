var x1 =document.getElementById("num1");
var x2 =document.getElementById("num2");
var result =document.getElementById("result");
function add(){
    result.innerHTML =parseInt(x1.value) + parseInt(x2.value);
}

function sub(){
    result.innerHTML =parseInt(x1.value) - parseInt(x2.value);
}

function mul(){
    result.innerHTML =parseInt(x1.value) * parseInt(x2.value);
}

function div(){
    result.innerHTML =parseInt(x1.value) / parseInt(x2.value);
}